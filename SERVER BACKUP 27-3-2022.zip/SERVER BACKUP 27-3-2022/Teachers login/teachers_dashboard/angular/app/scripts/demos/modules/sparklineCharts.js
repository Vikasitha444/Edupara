angular
  .module('theme.demos.sparkline_charts', [
    'theme.chart.sparklines'
  ]);