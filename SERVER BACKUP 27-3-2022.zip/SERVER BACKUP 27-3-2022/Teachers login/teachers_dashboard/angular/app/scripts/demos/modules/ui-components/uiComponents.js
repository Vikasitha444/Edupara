angular
  .module('theme.demos.ui_components', [
    'ui.tree'
  ]);